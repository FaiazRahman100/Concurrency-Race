//
//  ViewController.swift
//  faiaz_Rahman_30024_Concurrency
//
//  Created by bjit on 27/12/22.
//

import UIKit

var winnerFlag = 0

class ViewController: UIViewController {

   // @IBOutlet weak var task1BG: UIView!
    @IBOutlet weak var task1Label: UILabel!
    
   // @IBOutlet weak var task2BG: UIView!
    @IBOutlet weak var task2Label: UILabel!
    
   // @IBOutlet weak var task3BG: UIView!
    @IBOutlet weak var task3Label: UILabel!

    @IBOutlet weak var task4Label: UILabel!
    
   // @IBOutlet var taskBGViews: [UIView]!
    @IBOutlet var taskLabels: [UILabel]!
    
    
    @IBOutlet weak var imageView1: UIImageView!
    
    @IBOutlet weak var imageView2: UIImageView!
    
    @IBOutlet weak var imageView3: UIImageView!
    
    @IBOutlet weak var imageView4: UIImageView!
    
    @IBOutlet var imageCollection: [UIImageView]!
    
    @IBOutlet weak var WinnerLabel: UILabel!
    
    @IBOutlet weak var finishImage: UIImageView!
    // var imageViewsAll : [UIImageView] = [imageView1,imageView2,imageView3,imageView4]
    
    var imageYCollection : [Int] = [200,350,500,650]
    var playerName : [String] = ["Dragon", "Naruto", "Sonic", "Batman"]
    var imageName : [String] = ["dragonStand", "narutoStand", "sonicStand", "batmanStand"]
    
    //let colors: [UIColor] = [UIColor.red, UIColor.brown, UIColor.orange, UIColor.yellow, UIColor.green]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        taskBGViews.append(task2BG)
//        taskBGViews.append(task3BG)
        
        imageCollection.append(imageView2)
        imageCollection.append(imageView3)
        imageCollection.append(imageView4)
        
        taskLabels.append(task2Label)
        taskLabels.append(task3Label)
        taskLabels.append(task4Label)
        
        print(imageCollection.count)
        print(taskLabels.count)
        
        setInitialPosition()

        
        loadImagesGig()
        //setInitialLabel()
        
       
        
        // Do any additional setup after loading the view.
    }
    
    func loadImagesGig(){
        imageView1.loadGif(name: "dragon")
        imageView2.loadGif(name: "Naruto")
        imageView3.loadGif(name: "sonic2")
        imageView4.loadGif(name: "batman")
        finishImage.loadGif(name: "sdfg")
    }
    
    func setInitialLabel(){
        task1Label.text = "0%"
        task2Label.text = "0%"
        task3Label.text = "0%"
        task4Label.text = "0%"
    }
    
    func setInitialPosition(){
        imageView1.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageView1.center = CGPoint(x: 60, y: 200)
        imageView2.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageView2.center = CGPoint(x: 60, y: 350)
        imageView3.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageView3.center = CGPoint(x: 60, y: 500)
        imageView4.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageView4.center = CGPoint(x: 60, y: 650)
    }
    
    
    @IBAction func dispatchButton(_ sender: Any) {
        loadImagesGig()
        setInitialPosition()
        setInitialLabel()
        winnerFlag = 0
        WinnerLabel.text = "Who will be the winner?"
        
        
        let actionSheet = UIAlertController(title: "Action Sheet", message: "Please Select Any", preferredStyle: .actionSheet)
        let globalAsync = UIAlertAction(title: "Global Async", style: .default) { (action) in
            
            //DispatchQueue.global().async {[weak self] in
                self.dispatchAllToGlobalQueueAsync()
           // }
            
        }
        let globalSync = UIAlertAction(title: "Global Sync", style: .default) { (action) in
            
            // global makes it realtime otherwise wait
            DispatchQueue.global().async {[weak self] in
                self?.dispatchAllToGlobalQueueSync()
            }
            
        }
        
        let privateConcurrentAsync = UIAlertAction(title: "Private Concurrent Async", style: .default) { (action) in
            
          //  DispatchQueue.global().async {[weak self] in
            self.dispatchAlltoCustomQueueAsync(attribute: .concurrent)
          //  }
        }
        
        let privateSerialSync = UIAlertAction(title: "Private Serial Sync", style: .default) { (action) in
            // global makes it realtime otherwise wait
            DispatchQueue.global().async {[weak self] in
            self?.dispatchAlltoCustomQueueSerialSync()
            }
        }
        let privateSerialAsync = UIAlertAction(title: "Private Serial ASync", style: .default) { (action) in
            
            //DispatchQueue.global().async {[weak self] in
            self.dispatchAlltoCustomQueueSerialASync()
            //}
        }
        
        
        let cancel = UIAlertAction(title: "Cancel", style: .default)
        
        actionSheet.addAction(globalAsync)
        actionSheet.addAction(globalSync)
        actionSheet.addAction(privateSerialSync)
        actionSheet.addAction(privateSerialAsync)
        actionSheet.addAction(privateConcurrentAsync)
        actionSheet.addAction(cancel)
        
        present(actionSheet, animated: true)

    }
    
    func dispatchAllToGlobalQueueSync(){
        
        let queue1 = DispatchQueue.global()
        
        queue1.sync {[weak self] in
            self?.doTask(with: 0)
        }
        queue1.sync {[weak self] in
            self?.doTask(with: 1)
        }
        queue1.sync {[weak self] in
            self?.doTask(with: 2)
        }
        queue1.sync {[weak self] in
            self?.doTask(with: 3)
        }
    }
    
    func dispatchAllToGlobalQueueAsync(){
        
        let queue2 = DispatchQueue.global()
        
        queue2.async {[weak self] in
            self?.doTask(with: 0)
        }
        queue2.async {[weak self] in
            self?.doTask(with: 1)
        }
        queue2.async {[weak self] in
            self?.doTask(with: 2)
        }
        queue2.async {[weak self] in
            self?.doTask(with: 3)
        }
    }
    
    
    func dispatchAlltoCustomQueueAsync(attribute : DispatchQueue.Attributes?){
        if let attribute = attribute {
            let queue = DispatchQueue(label: "com.customA.queue", attributes: attribute)
            for index in 0..<4{
                queue.async { [weak self] in
                    self?.doTask(with: index)
                }
            }
        }else{
            let queue = DispatchQueue(label: "com.customB.queue")
            for index in 0..<4{
                queue.async { [weak self] in
                    self?.doTask(with: index)
                }
                
            }
    }
    }
    
    func dispatchAlltoCustomQueueSerialSync(){
        
            let queue = DispatchQueue(label: "com.customC.queue")
            for index in 0..<4{
                queue.sync { [weak self] in
                    self?.doTask(with: index)
                }
            }
    }
    
    
    func dispatchAlltoCustomQueueSerialASync(){
        
            let queue = DispatchQueue(label: "com.customD.queue")
            for index in 0..<4{
                queue.async { [weak self] in
                    self?.doTask(with: index)
                }
            }
    }
    
    func doTask(with index: Int){
//        for i in 0..<5{
//            //sleep(UInt32.random(in: 0...2))
//            DispatchQueue.main.async {[weak self] in
//                self?.taskBGViews[index].backgroundColor = self?.colors[i]
//                self?.taskLabels[index].text = "task \(index+1) of \((i+1) * 20) copmplete "
//            }
//        }
        
        for i in 1..<11{
            sleep(UInt32.random(in: 0...1))
            DispatchQueue.main.async {[weak self] in
                
                let xPosition = 60 +  30 * (i)
                self?.imageCollection[index].center = CGPoint(x: xPosition, y: (self?.imageYCollection[index])!)
                self?.taskLabels[index].text = "\((i*10)) %"
                print(xPosition)
                
                if i == 10{
                    self?.imageCollection[index].image = UIImage(named: (self?.imageName[index])!)
                }
                
                if winnerFlag == 0 && i == 10{
                    self?.WinnerLabel.text = ("Winner : \((self?.playerName[index])!)")
                    self?.finishImage.loadGif(name: "cb2")
                    winnerFlag = 1
                }
            }
        }
//        taskLabels[index].text = "0 %"
//        winnerFlag = winnerFlag + 1
//        if winnerFlag == 1 {
//            WinnerLabel.text = "Winner Naruto"
//        }
        
        
    }


}

