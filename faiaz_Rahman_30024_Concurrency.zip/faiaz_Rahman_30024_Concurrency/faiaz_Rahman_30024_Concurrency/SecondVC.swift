//
//  SecondVC.swift
//  faiaz_Rahman_30024_Concurrency
//
//  Created by Faiaz Rahman on 27/12/22.
//

import UIKit
var xPoint: Double = 60
class SecondVC: UIViewController {
    
    @IBOutlet weak var imageV: UIImageView!
    
    @IBOutlet weak var imageV2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageV.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageV.center = CGPoint(x: 60, y: 200)
        imageV2.frame = CGRect(x: -1, y: -1, width: 100, height: 200)
        imageV2.center = CGPoint(x: 60, y: 400)

        imageV.loadGif(name: "dragon")
        imageV2.loadGif(name: "Naruto")
        //imageV.loadGif(name: "humanB")
        //imageV.frame = CGRect(x: 190, y: 100, width: 100, height: 200)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnTapped(_ sender: Any) {
        
        DispatchQueue.global().async {[weak self] in
        self?.doMove()
        }
        
    }
    func doMove(){
        
        let queue = DispatchQueue.global()
        queue.async {[weak self] in
            for i in 1..<6{
                sleep(UInt32.random(in: 0...2))
                DispatchQueue.main.async {[weak self] in
                    
                    var x = 60 + 48 * (i)
                    self?.imageV.center = CGPoint(x: x, y: 200)
                    print(x)
                }
                
                
                // imageV2.center = CGPoint(x: x, y: 400)
                //xPoint = xPoint + 10
                
            }
        }
        queue.async {[weak self] in
            for i in 1..<6{
                sleep(UInt32.random(in: 0...2))
                DispatchQueue.main.async {[weak self] in
                    
                    var x = 60 + 48 * (i)
                    self?.imageV2.center = CGPoint(x: x, y: 400)
                    print(x)
                }
            }
        }
//        for i in 1..<6{
//            var x = 60 + 48 * (i)
//            imageV.center = CGPoint(x: x, y: 200)
//            imageV2.center = CGPoint(x: x, y: 400)
//            //xPoint = xPoint + 10
//            print(x)
//
//        }
        
    }
    
}
